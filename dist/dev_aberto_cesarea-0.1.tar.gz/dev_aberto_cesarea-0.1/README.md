# DistribuicaoDeSoftware

Nesse projeto haverá um pequeno pacote Python instalável via pip

#Link para o repositório da disciplina
https://github.com/Insper/dev-aberto
